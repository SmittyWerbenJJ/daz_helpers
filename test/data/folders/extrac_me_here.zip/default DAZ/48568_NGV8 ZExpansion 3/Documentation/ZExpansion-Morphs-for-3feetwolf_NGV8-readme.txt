*******************************************************
Product Name: ZExpansion Morphs for New Genitalia For Victoria 8
Author: Zev0
Copyright January 2019

zev01f@gmail.com

https://www.renderotica.com/content-artists/Zev0/733
*******************************************************



Installation instructions:

1. Copy Contents of Product Zip to your Content directory

*******************************************************


Product Content list

Genitalia Morphs on Figure For Both Genesis 3 & 8 Female (Located Parameters\Morphs\NGV8 ZExpansion)

-ZExpansion Anus Gape
-ZExpansion Vag Gape
-ZExpansion Width Gape Extra


Genitalia Morphs on Genitalia (located Parameters\Actor\ZExpansion)

-Actor/ZExpansion/01 Vag External

Clitoris Bigger
Clitoris Hang Height
Vag Gape Height
Vag Gape Width
Vag Height Adjust
Vag Labia Inward
Vag Push & Pull

-Actor/ZExpansion/02 Vag Internal

Cervix Depth
Cervix Open
Cervix Size
Vag Internal Depth Adjust
Vag Internal Diameter
Vag Internal Height Adjust
Vag Internal Internal Ribbed Detail
Vag Internal Prolapse (Use Preset)

-Actor/ZExpansion/03 Perineum Area

Perineum Center Height
Perineum Distance
Perineum Height Adjust
Anus Gape Width
Anus Move UpDown
Anus Rim Pull
Anus Rim Thickness

-Actor/ZExpansion/4 Anus External

Anus Center Height Bottom
Anus Center Height Top
Anus Gape Height
Anus Gape Width
Anus Push & Pull
Anus Rim Detail
Anus Rim Height Adjust
Anus Rim Push & Pull
Anus Rim Thickness

-Actor/ZExpansion/05 Anus Internal

Anus Internal Depth Adjust
Anus Internal Diameter
Anus Internal Height Adjust
Anus Internal Hide
Anus Internal Prolapse (Use Preset)
Anus Internal Ribbed Detail


-Presets (Located People\Genesis 8 Female\Anatomy\New Genitalia for Victoria 8\NGV8 ZExpansion

-Figure Shape Presets

Figure Gape Prepare (Apply to figure first before product use)
Figure Gape Zero

-Genital Shape Presets

Zero Shape
Anus Gape
Anus Prolapse
Gape Both
Vag Gape
Vag Prolapse

-Zero Presets

Zero All
Zero Anus External Morphs
Zero Anus Internal Morphs
Zero Perineum Morphs
Zero Vag External Morphs
Zero Vag Internal Morphs



*******************************************************

Product also compatible with Bend Control
https://www.daz3d.com/bend-control-for-genesis-8-female-s-46267
https://www.daz3d.com/bend-control-for-genesis-3-female-s

