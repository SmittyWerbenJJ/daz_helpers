*******************************************************
Product Name: ZExpansion Morphs 3 for New Genitalia For Victoria 8
Author: Zev0
Copyright 2021

zev01f@gmail.com

https://www.renderotica.com/content-artists/Zev0/733
*******************************************************


Installation instructions:

1. Copy Contents of Product Zip to your Content directory

*******************************************************

Product Content list

Added Genitalia Morphs on Genitalia (located Parameters\Actor\ZExpansion)

-Actor/ZExpansion/01 Vag External

Mons Pubis Adjust
Urethra Expand Height
Urethra Expand Width
Urethra Move Up Down
Urethra Swell
Vag Majora Open Close
Vag Majora Pull
Vag Minora Open Close
Vag Minora Pull
Vag Minora Shape Adjust
Vag Minora Swell
Vag Offset X
Vag Size Bigger
Vag Size Bigger Open Above
Vag Size Bigger Open Bottom


-Presets (Located People\Genesis 8 Female\Anatomy\New Genitalia for Victoria 8\NGV8 ZExpansion

-Zero Presets Updated to register new morphs

Zero All
Zero Anus External Morphs
Zero Anus Internal Morphs
Zero Perineum Morphs
Zero Super Clitoris Morphs
Zero Vag External Morphs
Zero Vag Internal Morphs

Hidden Morph Properties

Urethra Expand Assist
Urethra Expand Width Assist
Urethra Move Up Assist
Vag Majora Close Only Assist
Vag Majora Close Only Assist 2
Vag Majora Open & Gape Width Assist
Vag Majora Open Only Assist
Vag Majora Open Only Assist 2
Vag Minora Flaps Open Assist
Vag Minora Flaps Open Assist Null
Vag Offset Left
Vag Offset Left Assist
Vag Offset Right
Vag Offset Right Assist
Vag Size Bigger Assist 1
Vag Size Bigger Assist 2
Vag Size Bigger Assist 3
Vag Size Bigger Assist 4
Vag Size Bigger Open Above Assist
Vag Size Bigger Open Both Assist





*******************************************************

Product also compatible with Bend Control
https://www.daz3d.com/bend-control-for-genesis-8-female-s
https://www.daz3d.com/bend-control-for-genesis-3-female-s

